package com.example.bdanimales

class cMascota {

    var id:Int = 0
    var nombre: String = ""
    var categoria: String = ""

    // Objetos del tipo mascota Vacio
    constructor(){
        this.id = 0
        this.nombre = ""
        this.categoria = ""
    }

    constructor(id: Int, nombre: String, categoria: String) {
        this.id = id
        this.nombre = nombre
        this.categoria = categoria
    }

}