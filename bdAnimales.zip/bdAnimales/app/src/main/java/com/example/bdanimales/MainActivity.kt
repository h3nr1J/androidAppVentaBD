package com.example.bdanimales

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {

    private lateinit var txtId: EditText
    private lateinit var txtNombre: EditText
    private lateinit var txtCategoria: EditText
    private lateinit var btnAgregar: ImageButton
    private lateinit var btnEliminar: ImageButton
    private lateinit var btnActualizar: ImageButton
    private lateinit var btnNuevo: ImageButton
    private lateinit var btnVaciar: ImageButton
    private lateinit var spLista: Spinner
    private lateinit var odbMascota:dbMascota


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "BD MASCOTA"
        IniciarComponentes()
        odbMascota = dbMascota(this)
        listar()
    }
    // Conecction to DATA BASE
    private fun IniciarComponentes(){
        txtId = findViewById(R.id.txtId)
        txtNombre = findViewById(R.id.txtNombre)
        txtCategoria = findViewById(R.id.txtCategoria)
        btnAgregar = findViewById(R.id.btnAgregar)
        btnEliminar = findViewById(R.id.btnEliminar)
        btnActualizar = findViewById(R.id.btnActualizar)
        btnNuevo = findViewById(R.id.btnNuevo)
        btnVaciar = findViewById(R.id.btnVaciar)
        spLista = findViewById(R.id.spLista)
    }
    // Lista Tmascota y muestra en Spinner
    fun listar(){
        val listaMascota = odbMascota.listar()
        var lista = ArrayList<String>()
        for(oMascota in listaMascota){
            lista.add(oMascota.id.toString()+ " - " + oMascota.nombre +" - "+  oMascota.categoria  )
        }
        val arrayAdp = ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,lista)
        spLista.adapter  = arrayAdp

        spLista?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{

            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                var item = spLista.getSelectedItem().toString()
                val list = item.split(" - ")
                list.sorted()
                val oMascota = odbMascota.recuperar(list[0].toString().toInt())

                txtId.setText(oMascota.id.toString())
                txtNombre.setText(oMascota.nombre.toString())
                txtCategoria.setText(oMascota.categoria.toString())
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {
                LimpiaCajas()
            }

        }
    }
    fun LimpiaCajas(){
        txtId.setText("")
        txtNombre.setText("")
        txtCategoria.setText("")
    }
    fun Recuperar(view: View){
        val oMascota = odbMascota.recuperar(txtId.text.toString().toInt())
        if(oMascota == null){
            val alerta = AlertDialog.Builder(this)
            alerta.setTitle("Datos")
            alerta.setMessage("Dato no existente")
            LimpiaCajas()
        }else{
            txtId.setText(oMascota.id.toString())
            txtNombre.setText(oMascota.nombre.toString())
            txtCategoria.setText(oMascota.categoria.toString())
        }
    }

    fun Vaciar(view: View){
        odbMascota.vaciar()
        listar()
        LimpiaCajas()

    }
    fun Agregar(view: View) {
        odbMascota.insertar(txtNombre.text.toString(),txtCategoria.text.toString())
        listar()

    }
    fun Nuevo(view: View){
        LimpiaCajas()
    }
    fun Eliminar(view: View){
        odbMascota.eliminar(txtId.text.toString().toInt())
        listar()
    }
    fun Actualizar(view: View){
        odbMascota.actualizar(txtId.text.toString().toInt(),txtNombre.text.toString(),txtCategoria.text.toString())
        listar()
        LimpiaCajas()
    }
}