package com.example.bdanimales

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.lang.Exception

class dbMascota (context: Context)  : SQLiteOpenHelper(context,"mascota.db",null,1){

    // Crear la base de datos
    override fun onCreate(db: SQLiteDatabase?) {
        // Creacion de las tablas
        val sql = "CREATE TABLE tMascota("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "nombre TEXT, categoria TEXT)"

        db!!.execSQL(sql)

    }

    // onUpgrade : Actualiar BD
    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        val sql = "DROP TABLE IF EXISTS tMascota"
        db!!.execSQL(sql)
    }

    // Function for the inster in table "Talumno"
    fun insertar(nombre:String, categoria:String):Long{
        val dato = ContentValues()
        dato.put("nombre",nombre)
        dato.put("categoria",categoria)
        val db = this.writableDatabase
        val suceso = db.insert("tMascota",null,dato)
        db.close()
        return suceso
    }
    // Function for the Alumns relationships for Alphabetic order
    fun listar():ArrayList<cMascota>{
        val list: ArrayList<cMascota> = ArrayList()
        val sql = "SELECT * FROM tMascota Order By nombre"
        val db = this.readableDatabase
        val cursor : Cursor?
        try {
            cursor = db.rawQuery(sql,null)
        }catch (e: Exception){
            e.printStackTrace()
            db.execSQL(sql)
            return ArrayList()
        }
        var id:Int
        var nombre:String
        var categoria:String
        if(cursor.moveToFirst()){
            do {
                id = cursor.getInt(0)
                nombre = cursor.getString(1)
                categoria = cursor.getString(2)
                val alu: cMascota
                alu  = cMascota(id, nombre, categoria)
                list.add(alu)
            }while (cursor.moveToNext())
        }
        return list
    }


    fun vaciar(){
        val sql = "DELETE FROM tMascota"
        val db = this.writableDatabase
        db!!.execSQL(sql)
    }

    // Recover data Alum on id function

    fun recuperar(id:Int):cMascota{
        val list: ArrayList<cMascota> = ArrayList()
        val sql = "SELECT * FROM tMascota WHERE id = '$id'"
        val db = this.readableDatabase
        val cursor: Cursor?
        try {
            cursor = db.rawQuery(sql,null)
        }catch (e: Exception){
            e.printStackTrace()
            db.execSQL(sql)
            return cMascota()
        }
        val oMascota = cMascota()
        if (cursor.moveToFirst()){
            oMascota.id = cursor.getInt(0)
            oMascota.nombre = cursor.getString(1)
            oMascota.categoria = cursor.getString(2)
        }
        return oMascota
    }

    // Update data the Alum as name or email
    fun actualizar(id:Int, nombre: String,categoria: String):Int{
        val db  = this.writableDatabase
        val dato  = ContentValues()
        dato.put("id",id)
        dato.put("nombre",nombre)
        dato.put("categoria",categoria)

        val suceso = db.update("tMascota",dato,"id="+id,null)
        db.close()
        return suceso
    }
    // Remove data in function with ID

    fun eliminar(id:Int):Int{
        val db = this.writableDatabase
        val dato  = ContentValues()
        dato.put("id",id)
        val suceso  = db.delete("tMascota","id=$id",null)
        db.close()
        return suceso
    }
}