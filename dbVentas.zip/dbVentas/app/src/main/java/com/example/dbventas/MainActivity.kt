package com.example.dbventas

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    private lateinit var oBD : cBD
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        oBD = cBD(this)
    }

    fun act_Producto(view: View){
        val intencion = Intent(this, act_productos::class.java)
        startActivity(intencion)
    }
    fun act_Boleta(view: View){
        val intencion = Intent(this, act_boleta::class.java)
        startActivity(intencion)
    }

    fun act_Detalle(view: View){
        val intencion = Intent(this, act_detalle::class.java)
        startActivity(intencion)
    }
}