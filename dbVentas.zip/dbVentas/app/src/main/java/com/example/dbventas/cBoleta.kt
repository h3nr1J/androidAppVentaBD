package com.example.dbventas

class cBoleta {

    var id: String = ""
    var fecha : String = ""
    var nombreCliente: String = ""
    var direccion : String= ""

    constructor(){
        this.id = ""
        this.fecha = ""
        this.nombreCliente = ""
        this.direccion = ""
    }
    constructor(id: String, fecha: String, nombreCliente: String, direccion: String) {
        this.id = id
        this.fecha = fecha
        this.nombreCliente = nombreCliente
        this.direccion = direccion
    }
}