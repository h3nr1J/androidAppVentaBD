package com.example.dbventas

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import java.time.LocalDateTime

class act_boleta : AppCompatActivity() {


    private lateinit var txtIdBoleta: EditText
    private lateinit var txtNombreCliente: EditText
    private lateinit var txtFecha: EditText
    private lateinit var txtDireccion: EditText
    private lateinit var oBD : cBD


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_act_boleta)
        title = "Datos de Boletas"
        IniciarComponente()
        oBD = cBD(this)

    }
    fun IniciarComponente(){
        txtIdBoleta = findViewById(R.id.txtIdBoleta)
        txtNombreCliente = findViewById(R.id.txtNombreCliente)
        txtFecha =  findViewById(R.id.txtFecha)
        txtDireccion =  findViewById(R.id.txtDireccion)
    }
    fun LimpiarComponentes(){
        txtIdBoleta.setText("")
        txtNombreCliente.setText("")
        txtDireccion.setText("")
        txtFecha.setText("")
    }
    fun Grabar(view: View){
        txtIdBoleta.setText(agregaCeros(3,txtIdBoleta.text.toString()))
        if(oBD.existeBoleta(txtIdBoleta.text.toString())){
            oBD.modificaBoleta(txtIdBoleta.text.toString(),
                txtNombreCliente.text.toString(),
                txtFecha.text.toString(),
                txtDireccion.text.toString()
                )
            notificacion("Modificado")
        }else{
            oBD.insertaBoleta(txtIdBoleta.text.toString(),
                txtNombreCliente.text.toString(),
                txtFecha.text.toString(),
                txtDireccion.text.toString()
                )
            notificacion("Insertado")
        }
    }
    fun mensaje(msg:String){
        val alerta = AlertDialog.Builder(this)
        alerta.setTitle("Mensaje")
        alerta.setMessage(msg)
        alerta.show()
    }
    fun Eliminar(view: View){
        txtIdBoleta.setText(agregaCeros(3,txtIdBoleta.text.toString()))
        if(oBD.existeBoleta(txtIdBoleta.text.toString())){
            oBD.eliminaBoleta(txtIdBoleta.text.toString())
            notificacion("Datos eliminados")
            LimpiarComponentes()
        }else{
            notificacion("El dato no existe")
        }
    }
    @RequiresApi(Build.VERSION_CODES.O)
    fun Nuevo(view: View){
        val sgte = oBD.sgteBoleta()
        txtIdBoleta.setText(sgte)
        txtNombreCliente.setText("")
        txtFecha.setText(LocalDateTime.now().dayOfMonth.toString()+"/"+
                LocalDateTime.now().monthValue.toString()+"/"+
                LocalDateTime.now().year.toString())
        txtDireccion.setText("")
    }
    fun Recuperar(view: View){
        txtIdBoleta.setText(agregaCeros(3,txtIdBoleta.text.toString()))
        if(oBD.existeBoleta(txtIdBoleta.text.toString())){
            val oBoleta = oBD.recuperaBoleta(txtIdBoleta.text.toString())
            txtIdBoleta.setText(oBoleta.id)
            txtNombreCliente.setText(oBoleta.nombreCliente)
            txtFecha.setText(oBoleta.fecha)
            txtDireccion.setText(oBoleta.direccion)
            notificacion("Datos recuperados")
        }else{
            notificacion("El dato no existe")
        }
    }
    fun agregaCeros(n:Int, c:String):String{
        var cad = c
        while (cad.length < n)
            cad = "0" + cad
        return cad
    }
    fun notificacion(msg:String){
        val toast = Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG)
        toast.show()
    }
    fun Anterior(view: View){
        if(txtIdBoleta.text.toString() != "") {
            val ante = txtIdBoleta.text.toString().toInt() - 1
            if(ante >= 1) {
                val oBoleta = oBD.recuperaBoleta(agregaCeros(3, ante.toString()))
                txtIdBoleta.setText(oBoleta.id)
                txtNombreCliente.setText(oBoleta.nombreCliente)
                txtFecha.setText(oBoleta.fecha)
                txtDireccion.setText(oBoleta.direccion)
            }
        }else{
            val oBoleta = oBD.recuperaBoleta(agregaCeros(3, "001"))
            txtIdBoleta.setText(oBoleta.id)
            txtNombreCliente.setText(oBoleta.nombreCliente)
            txtFecha.setText(oBoleta.fecha)
            txtDireccion.setText(oBoleta.direccion)
        }
    }
    fun Siguiente(view: View){
        if(txtIdBoleta.text.toString() != "") {
            val sgte = txtIdBoleta.text.toString().toInt() + 1
            val ultimo = oBD.ultimoBoleta()
            if(sgte <= ultimo.toInt()) {
                val oBoleta = oBD.recuperaBoleta(agregaCeros(3, sgte.toString()))
                txtIdBoleta.setText(oBoleta.id)
                txtNombreCliente.setText(oBoleta.nombreCliente)
                txtFecha.setText(oBoleta.fecha)
                txtDireccion.setText(oBoleta.direccion)
            }
        }else{
            val oBoleta = oBD.recuperaBoleta(agregaCeros(3, oBD.ultimoBoleta()))
            txtIdBoleta.setText(oBoleta.id)
            txtNombreCliente.setText(oBoleta.nombreCliente)
            txtFecha.setText(oBoleta.fecha)
            txtDireccion.setText(oBoleta.direccion)
        }
    }

}