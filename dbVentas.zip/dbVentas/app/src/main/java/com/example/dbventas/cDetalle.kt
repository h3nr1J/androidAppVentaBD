package com.example.dbventas

class cDetalle

{
    var id: String = ""
    var producto : cProducto = cProducto()
    var boleta : cBoleta = cBoleta()
    var cantidad: String = ""
    var pu:String = ""
    constructor(){
        this.id = ""
        this.producto = cProducto()
        this.boleta = cBoleta()
        this.cantidad= ""
        this.pu = ""
    }

    constructor(id: String,  producto: cProducto,boleta: cBoleta,cantidad:String,pu:String) {
        this.id = id
        this.producto = producto
        this.boleta = boleta
        this.cantidad = cantidad
        this.pu = pu
    }

}