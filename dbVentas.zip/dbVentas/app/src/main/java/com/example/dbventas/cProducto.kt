package com.example.dbventas

class cProducto {

    var id:String = ""
    var nombre:String = ""
    var unidad:String = ""
    var precio:String = ""

    constructor(){
        this.id = ""
        this.nombre= ""
        this.unidad = ""
        this.precio= ""
    }
    constructor(id: String,nombre:String,unidad:String,precio:String) {
        this.id = id
        this.nombre = nombre
        this.unidad = unidad
        this.precio = precio
    }


}