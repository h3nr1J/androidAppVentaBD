package com.example.dbventas


import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.lang.Exception

class cBD(context:Context): SQLiteOpenHelper(context, "tienda.db", null,1) {

//==============================================================================
    // Definición de la BD

//==============================================================================

    override fun onCreate(db: SQLiteDatabase?) {
        val sql_tProducto ="CREATE TABLE tProducto " +
                "(IdProducto TEXT PRIMARY KEY, " +
                "Nombre TEXT, " +
                "UnidadMedida TEXT, " +
                "Precio TEXT)"
        val sql_tBoleta ="CREATE TABLE tBoleta " +
                "(IdBoleta TEXT PRIMARY KEY," +
                "Fecha TEXT," +
                "NombreCliente TEXT," +
                "Direccion TEXT)"
        val sql_tDetalle ="CREATE TABLE tDetalle " +
                "(IdDetalle TEXT PRIMARY KEY," +
                "IdBoleta TEXT, " +
                "Cantidad TEXT, " +
                "PU TEXT," +
                "IdProducto TEXT," +
                "FOREIGN KEY (IdBoleta) REFERENCES tBoleta(IdBoleta)," +
                "FOREIGN KEY (IdProducto) REFERENCES tProducto(IdProducto))"
        db!!.execSQL(sql_tProducto)
        db.execSQL(sql_tBoleta)
        db.execSQL(sql_tDetalle)
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        val sqlD = "DELETE FROM tDetalle"
        val sqlB = "DELETE FROM tBoleta"
        val sqlP = "DELETE FROM tProducto"

        db!!.execSQL(sqlD)
        db.execSQL(sqlB)
        db.execSQL(sqlP)
    }

//==============================================================================
    // Funciones de datos de producto

//==============================================================================
    fun insertaProducto (id:String, nombre : String,unidad:String,precio:String){
        val dato = ContentValues()
        dato.put("IdProducto", id)
        dato.put("Nombre", nombre)
        dato.put("UnidadMedida",unidad)
        dato.put("Precio",precio)
        val db = this.writableDatabase
        db.insert("tProducto", null, dato)
        db.close()
    }
    fun modificarProducto(id:String, nombre : String,unidad:String,precio:String){
        val dato = ContentValues()

        dato.put("IdProducto", id)
        dato.put("Nombre", nombre)
        dato.put("UnidadMedida",unidad)
        dato.put("Precio",precio)
        val db = this.writableDatabase
        db.update("tProducto", dato, "IdProducto='$id'", null)
        db.close()
    }
    fun eliminaProducto(id:String){
        val db = this.writableDatabase
        db.delete("tProducto","IdProducto='$id'", null)
        db.close()
    }
    fun recuperaProducto(id:String): cProducto{
        if (existeProducto(id)) {
            val sql = "SELECT * FROM tProducto WHERE IdProducto = '$id'"
            val db = this.readableDatabase
            val cursor: Cursor = db.rawQuery(sql, null)
            val oProducto = cProducto()
            cursor.moveToFirst()
            oProducto.id = cursor.getString(0)
            oProducto.nombre = cursor.getString(1)
            oProducto.unidad = cursor.getString(2)
            oProducto.precio = cursor.getString(3)
            return oProducto
        }
        return cProducto()
    }
    fun borraProducto(id:String){
        val db = this.writableDatabase
        db.delete("tProducto", "IdProducto='$id'", null)
        db.close()
    }
    fun existeProducto(id: String): Boolean{
        val sql = "SELECT * FROM tProducto WHERE IdProducto='$id'"
        val db = this.readableDatabase
        var cursor: Cursor = db.rawQuery(sql, null)
        if (cursor.getCount() == 0)
            return false
        else
            return true
    }
    fun sgteProducto(): String{
        val sql = "SELECT MAX(IdProducto) FROM tProducto RESULTADO;"
        val db = this.readableDatabase
        var cursor : Cursor?
        try{
            cursor = db.rawQuery(sql, null)
            cursor.moveToFirst()
            var nro = (cursor.getString(0).toInt() + 1).toString()
            while (nro.length < 3)
                nro = "0" + nro
            return nro
        }catch(e:Exception){
            return "001"}
    }
    fun ultimoProducto(): String{
        val sql = "SELECT MAX(IdProducto) FROM tProducto RESULTADO;"
        val db = this.readableDatabase
        var cursor : Cursor?
        try{
            cursor = db.rawQuery(sql, null)
            cursor.moveToFirst()
            return cursor.getString(0)
        }catch(e:Exception){
            return "000"
        }
    }
    fun vacioProducto(): Boolean{
        val sql = "SELECT * FROM tProducto"
        val db = this.readableDatabase
        var cursor: Cursor = db.rawQuery(sql, null)
        if (cursor.getCount() == 0)
            return true
        else
            return false
    }

//==============================================================================
    // Funciones de datos de Boleta

//==============================================================================
    fun insertaBoleta(id:String,fecha: String, nombre : String,direccion:String){
        val dato = ContentValues()
        dato.put("IdBoleta", id)
        dato.put("Fecha",fecha)
        dato.put("NombreCliente", nombre)
        dato.put("Direccion",direccion)
        val db = this.writableDatabase
        db.insert("tBoleta", null, dato)
        db.close()
    }
    fun modificaBoleta(id:String,fecha: String, nombre : String,direccion:String){
        val dato = ContentValues()
        dato.put("IdBoleta", id)
        dato.put("Fecha",fecha)
        dato.put("NombreCliente", nombre)
        dato.put("Direccion",direccion)
        val db = this.writableDatabase
        db.update("tBoleta", dato, "IdBoleta='$id'", null)
        db.close()
    }
    fun eliminaBoleta(id:String){
        val db = this.writableDatabase
        db.delete("tBoleta","IdBoleta='$id'", null)
        db.close()
    }
    fun recuperaBoleta(id:String): cBoleta{if (existeBoleta(id)) {
        val sql = "SELECT * FROM tBoleta WHERE IdBoleta = '$id'"
        val db = this.readableDatabase
        val cursor: Cursor = db.rawQuery(sql, null)
        val oBoleta = cBoleta()
        cursor.moveToFirst()
        oBoleta.id = cursor.getString(0)
        oBoleta.fecha = cursor.getString(1)
        oBoleta.nombreCliente = cursor.getString(2)
        oBoleta.direccion = cursor.getString(3)
        return oBoleta
    }
        return cBoleta()
    }
    fun borraBoleta(id:String){
        val db = this.writableDatabase
        db.delete("tBoleta", "IdBoleta='$id'", null)
        db.close()
    }
    fun existeBoleta(id: String): Boolean{
        val sql = "SELECT * FROM tBoleta WHERE IdBoleta='$id'"
        val db = this.readableDatabase
        var cursor: Cursor = db.rawQuery(sql, null)
        if (cursor.getCount() == 0)
            return false
        else
            return true
    }
    fun sgteBoleta(): String{
        val sql = "SELECT MAX(IdBoleta) FROM tBoleta RESULTADO;"
        val db = this.readableDatabase
        var cursor : Cursor?
        try{
            cursor = db.rawQuery(sql, null)
            cursor.moveToFirst()
            var nro = (cursor.getString(0).toInt() + 1).toString()
            while (nro.length < 3)
                nro = "0" + nro
            return nro
        }catch(e:Exception){
            return "001"
        }
    }
    fun ultimoBoleta(): String{
        val sql = "SELECT MAX(IdBoleta) FROM tBoleta RESULTADO;"
        val db = this.readableDatabase
        var cursor : Cursor?
        try{
            cursor = db.rawQuery(sql, null)
            cursor.moveToFirst()
            return cursor.getString(0)
        }catch(e:Exception){
            return "000"
        }
    }
    fun vacioBoleta(): Boolean{
        val sql = "SELECT * FROM tBoleta"
        val db = this.readableDatabase
        var cursor: Cursor = db.rawQuery(sql, null)
        if (cursor.getCount() == 0)
            return true
        else
            return false
    }

//==============================================================================
    // Funciones de datos de detalle

//==============================================================================
    fun insertaDetalle(id:String, idBoleta: String,
                         cantidad:String, pu:String,idProducto: String){
        val dato = ContentValues()
        dato.put("IdDetalle", id)
        dato.put("IdBoleta", idBoleta)
        dato.put("Cantidad", cantidad)
        dato.put("IdProducto", idProducto)
        dato.put("PU", pu)
        val db = this.writableDatabase
        db.insert("tDetalle", null, dato)
        db.close()
    }
    fun modificaDetalle(id:String, idBoleta: String,
                          cantidad:String, pu:String,idProducto: String){
        val dato = ContentValues()
        dato.put("IdDetalle", id)
        dato.put("IdBoleta", idBoleta)
        dato.put("Cantidad", cantidad)
        dato.put("IdProducto", idProducto)
        dato.put("PU", pu)
        val db = this.writableDatabase
        db.update("tDetalle", dato, "IdDetalle='$id'", null)
        db.close()
    }
    fun eliminaDetalle(id:String){
        val db = this.writableDatabase
        db.delete("tDetalle","IdDetalle='$id'", null)
        db.close()
    }
    fun recuperaDetalle(id:String): cDetalle{
        val sql = "SELECT * FROM tDetalle WHERE IdDetalle = '$id'"
        val db = this.readableDatabase
        val cursor : Cursor = db.rawQuery(sql, null)
        val oDetalle = cDetalle()
        cursor.moveToFirst()
        oDetalle.id = cursor.getString(0)
        oDetalle.boleta = recuperaBoleta(cursor.getString(1))
        oDetalle.cantidad = cursor.getString(2)
        oDetalle.pu = cursor.getString(2)
        oDetalle.producto = recuperaProducto(cursor.getString(3))

        return oDetalle
    }
    fun borraDetalle(id:String){
        val db = this.writableDatabase
        db.delete("tDetalle", "IdDetalle='$id'", null)
        db.close()
    }
    fun existeDetalle(id: String): Boolean{
        val sql = "SELECT * FROM tDetalle WHERE IdDetalle='$id'"
        val db = this.readableDatabase
        var cursor: Cursor = db.rawQuery(sql, null)
        if (cursor.getCount() == 0)
            return false
        else
            return true
    }
    fun sgteDetalle(): String{
        val sql = "SELECT MAX(IdDetalle) FROM tDetalle RESULTADO;"
        val db = this.readableDatabase
        var cursor : Cursor?
        try{
            cursor = db.rawQuery(sql, null)
            cursor.moveToFirst()
            var nro = (cursor.getString(0).toInt() + 1).toString()
            while (nro.length < 3)
                nro = "0" + nro
            return nro
        }catch(e:Exception){
            return "001"
        }
    }
    fun listarProducto(): ArrayList<cProducto>{
        val sql = "SELECT * FROM tProducto ORDER BY Nombre"
        val db = this.readableDatabase
        val cursor : Cursor = db.rawQuery(sql, null)
        var Lista : ArrayList<cProducto> = ArrayList()
        cursor.moveToFirst()
        do{
            var oProducto = cProducto()
            oProducto.id = cursor.getString(0)
            oProducto.nombre = cursor.getString(1)
            oProducto.unidad = cursor.getString(2)
            oProducto.precio = cursor.getString(3)
            Lista.add(oProducto)
        }while (cursor.moveToNext())
        return Lista
    }
    fun listarProductoString(): ArrayList<String>{
        val sql = "SELECT * FROM tProducto ORDER BY Nombre"
        val db = this.readableDatabase
        val cursor : Cursor = db.rawQuery(sql, null)
        var Lista : ArrayList<String> = ArrayList()
        cursor.moveToFirst()
        do{
            var cadena = cursor.getString(0)+" "+cursor.getString(1)
            Lista.add(cadena)
        }while (cursor.moveToNext())
        return Lista
    }
    fun listarBoleta(): ArrayList<cBoleta>{
        val sql = "SELECT * FROM tBoleta ORDER BY Nombre"
        val db = this.readableDatabase
        val cursor : Cursor = db.rawQuery(sql, null)
        var Lista : ArrayList<cBoleta> = ArrayList()
        cursor.moveToFirst()
        do{
            var oBoleta = cBoleta()
            oBoleta.id = cursor.getString(0)
            oBoleta.fecha = cursor.getString(1)
            oBoleta.nombreCliente = cursor.getString(2)
            oBoleta.direccion = cursor.getString(3)
            Lista.add(oBoleta)
        }while (cursor.moveToNext())
        return Lista
    }
    fun listarBoletaString(): ArrayList<String>{
        val sql = "SELECT * FROM tBoleta ORDER BY IdBoleta"
        val db = this.readableDatabase
        val cursor : Cursor = db.rawQuery(sql, null)
        var Lista : ArrayList<String> = ArrayList()
        cursor.moveToFirst()
        do{
            var cadena = cursor.getString(0)+" "+cursor.getString(1)
            Lista.add(cadena)
        }while (cursor.moveToNext())
        return Lista
    }
    fun ultimoDetalle(): String{
        val sql = "SELECT MAX(IdDetalle) FROM tDetalle RESULTADO;"
        val db = this.readableDatabase
        var cursor : Cursor?
        try{
            cursor = db.rawQuery(sql, null)
            cursor.moveToFirst()
            return cursor.getString(0)
        }catch(e:Exception){
            return "000"
        }
    }

//==============================================================================

//==============================================================================
}