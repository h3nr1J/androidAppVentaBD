package com.example.dbventas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class act_productos : AppCompatActivity() {

    private lateinit var txtIdProducto: EditText
    private lateinit var txtNombreProducto: EditText
    private lateinit var txtUnidadMedida: EditText
    private lateinit var txtPrecio: EditText
    private lateinit var oBD : cBD

    private lateinit var btnNuevo:ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_act_productos)
        title = "Datos de Productos"
        IniciarComponente()
        oBD = cBD(this)

    }
    fun IniciarComponente(){
        txtIdProducto = findViewById(R.id.txtIdProducto)
        txtNombreProducto= findViewById(R.id.txtNombreProducto)
        txtUnidadMedida = findViewById(R.id.txtUnidadMedida)
        txtPrecio = findViewById(R.id.txtPrecio)
    }
    fun LimpiarComponentes(){

        txtIdProducto.setText("")
        txtNombreProducto.setText("")
        txtUnidadMedida.setText("")
        txtPrecio.setText("")
    }
    fun Grabar(view: View){
        txtIdProducto.setText(agregaCeros(3,txtIdProducto.text.toString()))
        if(oBD.existeProducto(txtIdProducto.text.toString())){
            oBD.modificarProducto(txtIdProducto.text.toString(),
                txtNombreProducto.text.toString(),
                txtUnidadMedida.text.toString(),
                txtPrecio.text.toString())
            notificacion("Modificado")
        }else{
            oBD.insertaProducto(
                txtIdProducto.text.toString(),
                txtNombreProducto.text.toString(),
                txtUnidadMedida.text.toString(),
                txtPrecio.text.toString()
                )
            notificacion("Insertado")
        }
    }
    fun mensaje(msg:String){
        val alerta = AlertDialog.Builder(this)
        alerta.setTitle("Mensaje")
        alerta.setMessage(msg)
        alerta.show()
    }
    fun Eliminar(view: View){
        txtIdProducto.setText(agregaCeros(3,txtIdProducto.text.toString()))
        if(oBD.existeProducto(txtIdProducto.text.toString())){
            oBD.eliminaProducto(txtIdProducto.text.toString())
            notificacion("Datos eliminados")
            LimpiarComponentes()
        }else{
            notificacion("El dato no existe")
        }
    }
    fun Nuevo(view: View){
        val sgte = oBD.sgteProducto()
        txtIdProducto.setText(sgte)
        txtNombreProducto.setText("")
        txtPrecio.setText("")
        txtUnidadMedida.setText("")
    }
    fun Recuperar(view: View){
        txtIdProducto.setText(agregaCeros(3,txtIdProducto.text.toString()))
        if(oBD.existeProducto(txtIdProducto.text.toString())){
            val oProducto = oBD.recuperaProducto(txtIdProducto.text.toString())
            txtIdProducto.setText(oProducto.id)
            txtNombreProducto.setText(oProducto.nombre)
            txtUnidadMedida.setText(oProducto.unidad)
            txtPrecio.setText(oProducto.precio)
            notificacion("Datos recuperados")
        }else{
            notificacion("El dato no existe")
        }
    }
    fun agregaCeros(n:Int, c:String):String{
        var cad = c
        while (cad.length < n)
            cad = "0" + cad
        return cad
    }
    fun notificacion(msg:String){
        val toast = Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG)
        toast.show()
    }
    fun Anterior(view: View){
        if(txtIdProducto.text.toString() != "") {
            val ante = txtIdProducto.text.toString().toInt() - 1
            if(ante >= 1) {
                val oProducto = oBD.recuperaProducto(agregaCeros(3,
                    ante.toString()))
                txtIdProducto.setText(oProducto.id)
                txtNombreProducto.setText(oProducto.nombre)
                txtUnidadMedida.setText(oProducto.unidad)
                txtPrecio.setText(oProducto.precio)
            }
        }else{
            val  oProducto= oBD.recuperaProducto(agregaCeros(3, "001"))
            txtIdProducto.setText(oProducto.id)
            txtNombreProducto.setText(oProducto.nombre)
            txtUnidadMedida.setText(oProducto.unidad)
            txtPrecio.setText(oProducto.precio)
        }
    }
    fun Siguiente(view: View){
        if(txtIdProducto.text.toString() != "") {
            val sgte = txtIdProducto.text.toString().toInt() + 1
            val ultimo = oBD.ultimoProducto()
            if(sgte <= ultimo.toInt()) {
                val oProducto = oBD.recuperaProducto(agregaCeros(3,
                    sgte.toString()))
                txtIdProducto.setText(oProducto.id)
                txtNombreProducto.setText(oProducto.nombre)
                txtUnidadMedida.setText(oProducto.unidad)
                txtPrecio.setText(oProducto.precio)
            }
        }else{
            val oProducto = oBD.recuperaProducto(agregaCeros(3, oBD.ultimoProducto()))
            txtIdProducto.setText(oProducto.id)
            txtNombreProducto.setText(oProducto.nombre)
            txtUnidadMedida.setText(oProducto.unidad)
            txtPrecio.setText(oProducto.precio)
        }
    }
}