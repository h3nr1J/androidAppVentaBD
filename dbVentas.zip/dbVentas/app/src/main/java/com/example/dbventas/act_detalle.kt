package com.example.dbventas


import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.annotation.RequiresApi

class act_detalle : AppCompatActivity() {


    private lateinit var txtIdDetalle: EditText
    private lateinit var txtIdDetalleBoleta : EditText
    private lateinit var spBoleta: Spinner
    private lateinit var txtCantidad: EditText
    private lateinit var txtPU: EditText
    private lateinit var txtIdDetalleProducto: EditText
    private lateinit var spProducto: Spinner
    private lateinit var oBD : cBD


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_act_detalle)
        IniciarComponentes()
        oBD = cBD(this)
        IniciarListas()
        //LlenarListas()
    }

    fun IniciarListas(){
        if(!oBD.vacioProducto()) {
            var ListaProductos = oBD.listarProductoString()
            val AdapterProducto = ArrayAdapter(
                this@act_detalle,
                android.R.layout.simple_spinner_dropdown_item,
                ListaProductos
            )
            spProducto.adapter = AdapterProducto
            spProducto?.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2:
                Int, p3: Long) {
                    var item = spProducto.getSelectedItem().toString()
                    val id = (item.split(" "))[0].toString()
                    val oProducto = oBD.recuperaProducto(id)
                    txtIdDetalleProducto.setText(oProducto.id)
                }
                override fun onNothingSelected(p0: AdapterView<*>?) {
                    txtIdDetalleProducto.setText("")
                }
            }
        }
        if(!oBD.vacioBoleta()) {
            var ListaBoletas = oBD.listarBoletaString()
            val AdapterBoleta = ArrayAdapter(
                this@act_detalle,
                android.R.layout.simple_spinner_dropdown_item,
                ListaBoletas
            )
            spBoleta.adapter = AdapterBoleta
            spBoleta?.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2:
                Int, p3: Long) {
                    var item = spBoleta.getSelectedItem().toString()
                    val id = (item.split(" "))[0].toString()
                    val oBoleta = oBD.recuperaBoleta(id)
                    txtIdDetalleBoleta.setText(oBoleta.id)
                }
                override fun onNothingSelected(p0: AdapterView<*>?) {
                    txtIdDetalleBoleta.setText("")
                }
            }
        }
    }
    fun IniciarComponentes(){
        txtIdDetalle = findViewById(R.id.txtIdDetalle)
        txtIdDetalleBoleta = findViewById(R.id.txtIdDetalleBoleta)
        spBoleta = findViewById(R.id.spBoleta)
        txtCantidad = findViewById(R.id.txtCantidad)
        txtPU = findViewById(R.id.txtPU)
        txtIdDetalleProducto = findViewById(R.id.txtIdProducto)
        spProducto = findViewById(R.id.spProducto)
    }
    fun LimpiarComponentes(){
        txtIdDetalle.setText("")
        txtCantidad.setText("")
        txtPU.setText("")
    }
    fun Grabar(view: View){
        txtIdDetalle.setText(agregaCeros(3,txtIdDetalle.text.toString()))
        if(oBD.existeDetalle(txtIdDetalle.text.toString())){
            oBD.modificaDetalle(txtIdDetalle.text.toString(),
                txtCantidad.text.toString(),
                txtIdDetalleProducto.text.toString(),
                txtIdDetalleBoleta.text.toString(),
                txtPU.text.toString())
            nota("Modificado")
        }else{
            oBD.insertaDetalle(txtIdDetalle.text.toString(),
                txtCantidad.text.toString(),
                txtIdDetalleProducto.text.toString(),
                txtIdDetalleBoleta.text.toString(),
                txtPU.text.toString())
            nota("Insertado")
        }
    }
    fun Eliminar(view: View){
        txtIdDetalle.setText(agregaCeros(3,txtIdDetalle.text.toString()))
        if(oBD.existeDetalle(txtIdDetalle.text.toString())){
            oBD.eliminaDetalle(txtIdDetalle.text.toString())
            nota("Datos eliminados")
            LimpiarComponentes()
        }else{
            nota("El dato no existe")
        }
    }
    @RequiresApi(Build.VERSION_CODES.O)
    fun Nuevo(view: View){
        val sgte = oBD.sgteDetalle()
        txtIdDetalle.setText(sgte)
        txtCantidad.setText("")
        txtIdDetalleProducto.setText("")
        txtIdDetalleBoleta.setText("")
        txtPU.setText("")
    }

    fun Recuperar(view: View){
        txtIdDetalle.setText(agregaCeros(3,txtIdDetalle.text.toString()))
        if(oBD.existeDetalle(txtIdDetalle.text.toString())){
            val oDetalle =
                oBD.recuperaDetalle(txtIdDetalle.text.toString())
            txtIdDetalle.setText(oDetalle.id)
            txtCantidad.setText(oDetalle.cantidad)
            txtPU.setText(oDetalle.pu)
            txtIdDetalleProducto.setText(oDetalle.producto.id)
            txtIdDetalleBoleta.setText(oDetalle.boleta.id)
            nota("recuperado")
        }else{
            nota("El dato no existe")
        }
    }
    fun agregaCeros(n:Int, c:String):String{
        var cad = c
        while (cad.length < n)
            cad = "0" + cad
        return cad
    }
    fun nota(msg:String){
        val toast = Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG)
        toast.show()
    }
    fun Anterior(view: View){
        if(txtIdDetalle.text.toString() != "") {
            val ante = txtIdDetalle.text.toString().toInt() - 1
            if(ante >= 1) {
                val oDetalle = oBD.recuperaDetalle(agregaCeros(3,
                    ante.toString()))
                txtIdDetalle.setText(oDetalle.id)
                txtCantidad.setText(oDetalle.cantidad)
                txtIdDetalleProducto.setText(oDetalle.producto.id)
                txtIdDetalleBoleta.setText(oDetalle.boleta.id)
                txtPU.setText(oDetalle.pu)
            }
        }else{
            val oDetalle = oBD.recuperaDetalle(agregaCeros(3, "001"))
            txtIdDetalle.setText(oDetalle.id)
            txtCantidad.setText(oDetalle.cantidad)
            txtIdDetalleProducto.setText(oDetalle.producto.id)
            txtIdDetalleBoleta.setText(oDetalle.boleta.id)
            txtPU.setText(oDetalle.pu)
        }
    }
    fun Siguiente(view: View){
        if( txtIdDetalle.text.toString()!= "") {
            val sgte = txtIdDetalle.text.toString().toInt() + 1
            val ultimo = oBD.ultimoDetalle()
            if(sgte <= ultimo.toInt()) {
                val oDetalle = oBD.recuperaDetalle(agregaCeros(3,
                    sgte.toString()))
                txtIdDetalle.setText(oDetalle.id)
                txtCantidad.setText(oDetalle.cantidad)
                txtIdDetalleProducto.setText(oDetalle.producto.id)
                txtIdDetalleBoleta.setText(oDetalle.boleta.id)
                txtPU.setText(oDetalle.pu)
            }
        }else{
            val oDetalle = oBD.recuperaDetalle(agregaCeros(3,
                oBD.ultimoProducto()))
            txtIdDetalle.setText(oDetalle.id)
            txtCantidad.setText(oDetalle.cantidad)
            txtIdDetalleProducto.setText(oDetalle.producto.id)
            txtIdDetalleBoleta.setText(oDetalle.boleta.id)
            txtPU.setText(oDetalle.pu)
        }
    }
}