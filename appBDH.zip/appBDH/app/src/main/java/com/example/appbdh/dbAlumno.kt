package com.example.appbdh
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.lang.Exception


class dbAlumno(context: Context)  : SQLiteOpenHelper(context,"alumno.db",null,1){

    // Crear la base de datos
    override fun onCreate(db: SQLiteDatabase?) {
        // Creacion de las tablas
        val sql = "CREATE TABLE tAlumno("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "nombre TEXT, email TEXT)"

        db!!.execSQL(sql)

    }

    // onUpgrade : Actualiar BD
    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
       val sql = "DROP TABLE IF EXISTS tAlumno"
        db!!.execSQL(sql)
    }

    // Function for the inster in table "Talumno"
    fun insertar(nombre:String, email:String):Long{
        val dato = ContentValues()
        dato.put("nombre",nombre)
        dato.put("email",email)
        val db = this.writableDatabase
        val suceso = db.insert("tAlumno",null,dato)
        db.close()
        return suceso
    }
    // Function for the Alumns relationships for Alphabetic order
    fun listar():ArrayList<cAlumno>{
        val list: ArrayList<cAlumno> = ArrayList()
        val sql = "SELECT * FROM tAlumno Order By nombre"
        val db = this.readableDatabase
        val cursor : Cursor?
        try {
            cursor = db.rawQuery(sql,null)
        }catch (e:Exception){
            e.printStackTrace()
            db.execSQL(sql)
            return ArrayList()
        }
        var id:Int
        var nombre:String
        var email:String
        if(cursor.moveToFirst()){
            do {
                id = cursor.getInt(0)
                nombre = cursor.getString(1)
                email = cursor.getString(2)
                val alu: cAlumno
                alu  = cAlumno(id, nombre, email)
                list.add(alu)
            }while (cursor.moveToNext())
        }
        return list
    }

    // Drop all data for table "tAlumno"

    fun vaciar(){
        val sql = "DELETE FROM tAlumno"
        val db = this.writableDatabase
        db!!.execSQL(sql)
    }

    // Recover data Alum on id function

    fun recuperar(id:Int):cAlumno{
        val list: ArrayList<cAlumno> = ArrayList()
        val sql = "SELECT * FROM tAlumno WHERE id = '$id'"
        val db = this.readableDatabase
        val cursor:Cursor?
        try {
            cursor = db.rawQuery(sql,null)
        }catch (e:Exception){
            e.printStackTrace()
            db.execSQL(sql)
            return cAlumno()
        }
        val oAlumno = cAlumno()
        if (cursor.moveToFirst()){
            oAlumno.id = cursor.getInt(0)
            oAlumno.nombre = cursor.getString(1)
            oAlumno.email = cursor.getString(2)
        }
        return oAlumno
    }

    // Update data the Alum as name or email
    fun actualizar(id:Int, nombre: String,email: String):Int{
        val db  = this.writableDatabase
        val dato  = ContentValues()
        dato.put("id",id)
        dato.put("nombre",nombre)
        dato.put("email",email)

        val suceso = db.update("tAlumno",dato,"id="+id,null)
        db.close()
        return suceso
    }
    // Remove data in function with ID

    fun eliminar(id:Int):Int{
        val db = this.writableDatabase
        val dato  = ContentValues()
        dato.put("id",id)
        val suceso  = db.delete("tAlumno","id=$id",null)
        db.close()
        return suceso
    }
}
