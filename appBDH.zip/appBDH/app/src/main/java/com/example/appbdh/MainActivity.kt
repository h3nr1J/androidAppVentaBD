package com.example.appbdh

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {

    private lateinit var txtId:EditText
    private lateinit var txtNombre:EditText
    private lateinit var txtEmail:EditText
    private lateinit var btnAgregar:ImageButton
    private lateinit var btnEliminar:ImageButton
    private lateinit var btnActualizar:ImageButton
    private lateinit var btnNuevo:ImageButton
    private lateinit var btnVaciar:ImageButton
    private lateinit var spLista:Spinner
    private lateinit var odbAlumno:dbAlumno


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "BD ALUMNO"
        IniciarComponentes()
        odbAlumno = dbAlumno(this)
        listar()

    }
    // Conecction to DATA BASE
    private fun IniciarComponentes(){
        txtId = findViewById(R.id.txtId)
        txtNombre = findViewById(R.id.txtNombre)
        txtEmail = findViewById(R.id.txtEmail)
        btnAgregar = findViewById(R.id.btnAgregar)
        btnEliminar = findViewById(R.id.btnEliminar)
        btnActualizar = findViewById(R.id.btnActualizar)
        btnNuevo = findViewById(R.id.btnNuevo)
        btnVaciar = findViewById(R.id.btnVaciar)
        spLista = findViewById(R.id.spLista)
    }
    // Lista Talumno y muestra en Spinner
    fun listar(){
        val listaAlumno = odbAlumno.listar()
        var lista = ArrayList<String>()
        for(oAlumno in listaAlumno){
            lista.add(oAlumno.nombre.toString() + " - " + oAlumno.id.toString())
        }
        val arrayAdp = ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,lista)
        spLista.adapter  = arrayAdp

        spLista?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{

            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                var item = spLista.getSelectedItem().toString()
                val list = item.split(" - ")
                val oAlumno = odbAlumno.recuperar(list[1].toString().toInt())
                txtId.setText(oAlumno.id.toString())
                txtNombre.setText(oAlumno.nombre.toString())
                txtEmail.setText(oAlumno.email.toString())
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {
                LimpiaCajas()
            }

        }
    }
    fun LimpiaCajas(){
        txtId.setText("")
        txtNombre.setText("")
        txtEmail.setText("")
    }
    fun Recuperar(view: View){
        val oAlumno = odbAlumno.recuperar(txtId.text.toString().toInt())
        if(oAlumno == null){
            val alerta = AlertDialog.Builder(this)
            alerta.setTitle("Datos")
            alerta.setMessage("Dato no existente")
            LimpiaCajas()
        }else{
            txtId.setText(oAlumno.id.toString())
            txtNombre.setText(oAlumno.nombre.toString())
            txtEmail.setText(oAlumno.email.toString())
        }
    }

    fun Vaciar(view: View){
        odbAlumno.vaciar()
        listar()
        LimpiaCajas()

    }
    fun Agregar(view: View) {
        odbAlumno.insertar(txtNombre.text.toString(),txtEmail.text.toString())
        listar()

    }
    fun Nuevo(view: View){
        LimpiaCajas()
    }
    fun Eliminar(view: View){
        odbAlumno.eliminar(txtId.text.toString().toInt())
        listar()
    }
    fun Actualizar(view: View){
        odbAlumno.actualizar(txtId.text.toString().toInt(),txtNombre.text.toString(),txtEmail.text.toString())
        listar()
        LimpiaCajas()
    }

}

