package com.example.appbdh

// Esto manejara los datos del alumno
class cAlumno {
    var id:Int = 0
    var nombre: String = ""
    var email: String = ""

    // Objetos del tipo alumno Vacios
   constructor(){
       this.id = 0
       this.nombre = ""
       this.email = ""
   }

    constructor(id: Int, nombre: String, email: String) {
        this.id = id
        this.nombre = nombre
        this.email = email
    }

}